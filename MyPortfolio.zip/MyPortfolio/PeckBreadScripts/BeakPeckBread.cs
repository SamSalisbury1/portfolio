﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeakPeckBread : MonoBehaviour
{
    public Transform bread;
    private SpriteRenderer spriteRend;
    public Sprite beak, beakWithCrumb;

    void Start()
    {
        spriteRend = GetComponent<SpriteRenderer>();
        spriteRend.sprite = beak;

        Vector3 diff = bread.position - transform.position;
        diff.Normalize();
        float rot_z = Mathf.Atan2(diff.y, diff.x) * Mathf.Rad2Deg;

        Quaternion q = Quaternion.AngleAxis(rot_z, Vector3.forward);
        transform.rotation = transform.rotation * q;
    }

    void Update()
    {
        transform.Translate(new Vector3(50f * Time.deltaTime, 0f, 0f));

        //If we are in bounds of the chosen area do not delete self.
        if (this.transform.position.x < 40 && this.transform.position.x > -40 && this.transform.position.y < 30 && this.transform.position.y > -30)
        {
            return;
        }

        Object.Destroy(this.gameObject);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        spriteRend.sprite = beakWithCrumb;
    }
}
