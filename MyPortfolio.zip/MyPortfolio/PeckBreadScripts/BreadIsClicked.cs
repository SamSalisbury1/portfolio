﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BreadIsClicked : MonoBehaviour
{
    public Player player;
    public GameObject Beak;
    public Text NumOfBirdsFed;

    public Transform BeakSpawner1;
    public Transform BeakSpawner2;
    public Transform BeakSpawner3;
    public Transform BeakSpawner4;
    public Transform BeakSpawner5;
    public Transform BeakSpawner6;
    public Transform BeakSpawner7;
    public Transform BeakSpawner8;
    public Transform BeakSpawner9;
    public Transform BeakSpawner10;
    public Transform BeakSpawner11;
    public Transform BeakSpawner12;
    public Transform BeakSpawner13;
    public Transform BeakSpawner14;
    public Transform BeakSpawner15;
    public Transform BeakSpawner16;

    private void Start()
    {
        player.LoadPlayer();
        NumOfBirdsFed.text = "Crumbs: " + player.crumbs;
    }

    private void OnMouseDown()
    {
        ChooseSpawner();
        player.UpdateCrumbs(1);
        NumOfBirdsFed.text = "Crumbs: " + player.crumbs;
    }

    private void ChooseSpawner()
    {
        int spawnerChoice = Random.Range(1, 16);

        if (spawnerChoice == 1)
        {
            SpawnPos1();
        }
        else if (spawnerChoice == 2)
        {
            SpawnPos2();
        }
        else if (spawnerChoice == 3)
        {
            SpawnPos3();
        }
        else if (spawnerChoice == 4)
        {
            SpawnPos4();
        }
        else if (spawnerChoice == 5)
        {
            SpawnPos5();
        }
        else if (spawnerChoice == 6)
        {
            SpawnPos6();
        }
        else if (spawnerChoice == 7)
        {
            SpawnPos7();
        }
        else if (spawnerChoice == 8)
        {
            SpawnPos8();
        }
        else if (spawnerChoice == 9)
        {
            SpawnPos9();
        }
        else if (spawnerChoice == 10)
        {
            SpawnPos10();
        }
        else if (spawnerChoice == 11)
        {
            SpawnPos11();
        }
        else if (spawnerChoice == 12)
        {
            SpawnPos12();
        }
        else if (spawnerChoice == 13)
        {
            SpawnPos13();
        }
        else if (spawnerChoice == 14)
        {
            SpawnPos14();
        }
        else if (spawnerChoice == 15)
        {
            SpawnPos15();
        }
        else if (spawnerChoice == 16)
        {
            SpawnPos16();
        }
    }

    private void SpawnPos1()
    {
        Instantiate(Beak, BeakSpawner1.position, Quaternion.identity);
    }

    private void SpawnPos2()
    {
        Instantiate(Beak, BeakSpawner2.position, Quaternion.identity);
    }

    private void SpawnPos3()
    {
        Instantiate(Beak, BeakSpawner3.position, Quaternion.identity);
    }

    private void SpawnPos4()
    {
        Instantiate(Beak, BeakSpawner4.position, Quaternion.identity);
    }

    private void SpawnPos5()
    {
        Instantiate(Beak, BeakSpawner5.position, Quaternion.identity);
    }

    private void SpawnPos6()
    {
        Instantiate(Beak, BeakSpawner6.position, Quaternion.identity);
    }

    private void SpawnPos7()
    {
        Instantiate(Beak, BeakSpawner7.position, Quaternion.identity);
    }

    private void SpawnPos8()
    {
        Instantiate(Beak, BeakSpawner8.position, Quaternion.identity);
    }

    private void SpawnPos9()
    {
        Instantiate(Beak, BeakSpawner9.position, Quaternion.identity);
    }

    private void SpawnPos10()
    {
        Instantiate(Beak, BeakSpawner10.position, Quaternion.identity);
    }

    private void SpawnPos11()
    {
        Instantiate(Beak, BeakSpawner11.position, Quaternion.identity);
    }

    private void SpawnPos12()
    {
        Instantiate(Beak, BeakSpawner12.position, Quaternion.identity);
    }

    private void SpawnPos13()
    {
        Instantiate(Beak, BeakSpawner13.position, Quaternion.identity);
    }

    private void SpawnPos14()
    {
        Instantiate(Beak, BeakSpawner14.position, Quaternion.identity);
    }

    private void SpawnPos15()
    {
        Instantiate(Beak, BeakSpawner15.position, Quaternion.identity);
    }

    private void SpawnPos16()
    {
        Instantiate(Beak, BeakSpawner16.position, Quaternion.identity);
    }

}
