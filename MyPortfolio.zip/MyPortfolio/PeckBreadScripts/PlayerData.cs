﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerData
{
    public int crumbs;

    public PlayerData (Player player)
    {
        crumbs = player.crumbs;
    }
}

