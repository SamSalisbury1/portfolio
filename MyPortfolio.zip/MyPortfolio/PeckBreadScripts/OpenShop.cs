﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenShop : MonoBehaviour
{
    public GameObject shop;
    public GameObject shopButton;
    public GameObject breadButton;

    public void ShopOpen()
    {
       // shopButton.SetActive(false);
       // breadButton.SetActive(false);
       // Vector3 pos = new Vector3(0, 0, 0);
       // Instantiate(shop, pos, Camera.main.transform.rotation);
    }
}
