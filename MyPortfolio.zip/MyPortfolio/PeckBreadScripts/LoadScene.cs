﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class LoadScene : MonoBehaviour
{
    public Animator transition;
    public float transitionTime = 1f;

    // In the build settings each scene has an index, this simply uses that index to load the desired scene after an a transition.
    public void SceneLoader(int sceneIndex)
    {
        StartCoroutine(StartLoadScene(sceneIndex));
    }

    IEnumerator StartLoadScene(int sceneIndex)
    {
        transition.SetTrigger("Start");

        yield return new WaitForSeconds(transitionTime);

        SceneManager.LoadScene(sceneIndex);

    }
}
