The .exe is stored in the folder called Samual_Salisbury_Simulated_Swarm_Intelligence_Executable.
To open the code in Unity open the folder Simulated_Swarm_Intelligence.
Run the ,exe in windowed mode, in a small screen resolution, stretch the window until all of the user interface is visible.